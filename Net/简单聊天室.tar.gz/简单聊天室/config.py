# -*- coding:utf-8 -*-
server_ADDR = ('0.0.0.0',11111)
client_ADDR = ("127.0.0.1",11111)